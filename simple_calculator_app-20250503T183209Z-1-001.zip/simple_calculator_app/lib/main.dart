import 'package:flutter/material.dart';

void main() {
  runApp(const MainApp());
}

class MainApp extends StatelessWidget {
  const MainApp({super.key});

  @override
  Widget build(BuildContext context) {
    return const MaterialApp(
      title: 'Calculator App',
      debugShowCheckedModeBanner: false,
      home: CalculatorApp(),
    );
  }
}

class CalculatorApp extends StatefulWidget {
  const CalculatorApp({super.key});

  @override
  State<CalculatorApp> createState() => _CalculatorAppState();
}

class _CalculatorAppState extends State<CalculatorApp> {
  String _output = "0";
  String _currentInput = "";
  String _operation = "";
  double _num1 = 0;
  double _num2 = 0;

  void _buttonPressed(String buttonText) {
    if (buttonText == "AC") {
      _clearAll();
    } else if (buttonText == "C") {
      _clearLast();
    } else if (buttonText == "+" ||
        buttonText == "-" ||
        buttonText == "×" ||
        buttonText == "÷" ||
        buttonText == "%") {
      _setOperation(buttonText);
    } else if (buttonText == "=") {
      _calculate();
    } else if (buttonText == ".") {
      _addDecimal();
    } else {
      _appendNumber(buttonText);
    }
  }

  void _clearAll() {
    setState(() {
      _output = "0";
      _currentInput = "";
      _operation = "";
      _num1 = 0;
      _num2 = 0;
    });
  }

  void _clearLast() {
    setState(() {
      if (_currentInput.isNotEmpty) {
        _currentInput = _currentInput.substring(0, _currentInput.length - 1);
        _output = _currentInput.isEmpty ? "0" : _currentInput;
      }
    });
  }

  void _setOperation(String op) {
    setState(() {
      if (_currentInput.isNotEmpty) {
        _num1 = double.parse(_currentInput);
        _operation = op;
        _currentInput = "";
        _output = _num1.toString() + " " + _operation;
      } else if (_operation.isNotEmpty) {
        _operation = op;
        _output = _num1.toString() + " " + _operation;
      }
    });
  }

  void _appendNumber(String number) {
    setState(() {
      if (number == "00" && _currentInput.isEmpty) {
        return; // Prevent leading "00"
      }
      _currentInput += number;
      _output = _currentInput;
    });
  }

  void _addDecimal() {
    setState(() {
      if (_currentInput.isEmpty) {
        _currentInput = "0.";
      } else if (!_currentInput.contains(".")) {
        _currentInput += ".";
      }
      _output = _currentInput;
    });
  }

  void _calculate() {
    if (_operation.isEmpty || _currentInput.isEmpty) return;

    setState(() {
      _num2 = double.parse(_currentInput);

      switch (_operation) {
        case "+":
          _currentInput = (_num1 + _num2).toString();
          break;
        case "-":
          _currentInput = (_num1 - _num2).toString();
          break;
        case "×":
          _currentInput = (_num1 * _num2).toString();
          break;
        case "÷":
          _currentInput = _num2 != 0 ? (_num1 / _num2).toString() : "Error";
          break;
        case "%":
          _currentInput = (_num1 % _num2).toString();
          break;
      }

      // Remove .0 if it's an integer
      if (_currentInput.endsWith(".0")) {
        _currentInput = _currentInput.substring(0, _currentInput.length - 2);
      }

      _output = _currentInput;
      _currentInput = "";
      _operation = "";
      _num1 = 0;
      _num2 = 0;
    });
  }

  Widget buildButton(String text, {Color? txtColor}) {
    txtColor ??= Colors.white;
    return ElevatedButton(
      onPressed: () => _buttonPressed(text),
      style: ElevatedButton.styleFrom(
        shape: const CircleBorder(),
        fixedSize: const Size(70, 70),
        backgroundColor: Colors.grey[900],
        foregroundColor: txtColor,
        elevation: 0,
        textStyle: const TextStyle(fontSize: 16),
      ),
      child: Text(text),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        title: Text("My Calculator", style: TextStyle(color: Colors.white)),
        backgroundColor: Colors.black,
        centerTitle: false,
      ),
      body: Column(
        mainAxisAlignment: MainAxisAlignment.end,
        children: [
          // Calculator Display
          Row(
            mainAxisAlignment: MainAxisAlignment.end,
            children: [
              Padding(
                padding: const EdgeInsets.all(15.0),
                child: Text(
                  _output,
                  style: TextStyle(color: Colors.white, fontSize: 48),
                ),
              ),
            ],
          ),

          //Calculator Buttons
          Column(
            mainAxisAlignment: MainAxisAlignment.end,
            children: [
              Padding(
                padding: const EdgeInsets.all(4.0),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceAround,
                  children: [
                    buildButton("AC", txtColor: Colors.cyan),
                    buildButton("%", txtColor: Colors.cyan),
                    buildButton("C", txtColor: Colors.cyan),
                    buildButton("÷", txtColor: Colors.red[500]),
                  ],
                ),
              ),
              Padding(
                padding: const EdgeInsets.all(4.0),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceAround,
                  children: [
                    buildButton("7"),
                    buildButton("8"),
                    buildButton("9"),
                    buildButton("×", txtColor: Colors.red[500]),
                  ],
                ),
              ),
              Padding(
                padding: const EdgeInsets.all(4.0),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceAround,
                  children: [
                    buildButton("4"),
                    buildButton("5"),
                    buildButton("6"),
                    buildButton("-", txtColor: Colors.red[500]),
                  ],
                ),
              ),
              Padding(
                padding: const EdgeInsets.all(4.0),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceAround,
                  children: [
                    buildButton("1"),
                    buildButton("2"),
                    buildButton("3"),
                    buildButton("+", txtColor: Colors.red[500]),
                  ],
                ),
              ),
              Padding(
                padding: const EdgeInsets.all(4.0),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceAround,
                  children: [
                    buildButton("00"),
                    buildButton("0"),
                    buildButton("."),
                    buildButton("=", txtColor: Colors.red[500]),
                  ],
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}
